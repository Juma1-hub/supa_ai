# Supa AI Backend — Stage 6 (Demo preflight and settlement safeguards)

## Included
- `POST /account/demo/preflight`: authenticated, read-only Demo balance + proposal + strategy progression + session/open-contract checks.
- `POST /account/demo/contract/monitor`: authenticated Demo contract status lookup. It only reports settlement when Deriv returns the matching contract ID with `is_sold` true and a valid Decimal profit.
- Settlement is applied through the existing engine's `on_confirmed_result`, which requires the contract ID to have been registered as open and rejects unknown contracts; duplicate settlements are idempotent.
- `POST /account/demo/buy` remains hard-locked (HTTP 423). No buy request is sent in Stage 6.
- No OAuth token, OTP URL, or proposal ID is persisted or returned.

## Important limitations
- The API still uses process-local strategy state. It is not multi-user safe or restart-persistent.
- Per-user Supa AI authentication/authorization and encrypted server-side session management are not implemented. Do not expose these endpoints publicly as a production trading service.
- The monitor requires an already-tracked open contract ID. A complete buy-to-monitor lifecycle is intentionally not enabled while purchases are locked.
- Tests use mocked Deriv responses; they do not establish live broker integration or real-money readiness.
- Live trading and Demo purchasing remain disabled.
