# Supa AI Backend — Stage 12

## Scope: user-scoped Demo execution-readiness hardening (read-only)

Stage 12 corrects a safety issue in the Demo purchase preflight path: it previously consulted the legacy process-global `engine` for the expected stake, session P/L, open-contract count and risk settings. That could mix risk state between users even though Stage 8 introduced per-user runtimes.

The preflight now:
- Requires the existing Supabase-authenticated user and Deriv OAuth bearer token.
- Requires an approved runtime belonging to that authenticated user.
- Fails closed if that runtime's persistence status is not ready.
- Checks expected stake, session stop-loss, take-profit and maximum open contracts against that user's isolated engine only.
- Returns the strategy ID, Martingale step, session P/L and open-contract count used for the read-only decision.
- Continues to request a Deriv Demo proposal only after the user's runtime and account/balance checks pass.
- Explicitly returns `purchase_enabled: false`; it does not send a Deriv `buy` request.

The global engine remains for legacy/non-user-specific endpoints only; it is no longer consulted by Demo preflight risk checks.

## Tests

Run from this directory:

```bash
PYTHONPATH=. pytest -q
```

Expected result for this package: **64 passed**.

Tests include proof that preflight uses the user runtime rather than the global engine, and fails closed if no user runtime exists or its persistence is unavailable.

## Not production approval

- This is not an enabled purchase workflow. `/account/demo/buy` remains HTTP 423 locked.
- No Deriv purchase has been sent; tests mock the account/proposal responses.
- Real Deriv and Supabase integration has not been verified against the user's accounts.
- Account-link ownership, final pre-buy revalidation, atomic purchase registration, crash recovery around an accepted buy, and live multi-worker coordination remain required before Demo purchasing can be considered.
- Do not deploy this package over the existing service without reviewing the complete migration/configuration and testing in a separate environment.
