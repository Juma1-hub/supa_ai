# Supa AI Backend — Stage 10: Runtime recovery integration

## Scope
This stage connects the existing Stage 9 Supabase runtime checkpoint adapter to the per-user strategy runtime. It does not enable broker execution.

## Changes
- Added validated restoration of Martingale step, session P/L, and tracked open contract IDs into a newly created per-user engine.
- Strategy approval now loads the checkpoint for the authenticated user and approved strategy, restores it, then writes an initial checkpoint before reporting the runtime ready.
- Strategy-statistics processing now checkpoints runtime state after processing. If persistence fails, that user's runtime is marked unavailable and subsequent statistics processing fails closed until reactivation/recovery.
- Runtime snapshots report Supabase checkpointing status rather than claiming the state is memory-only.
- Added tests for restore, stake progression after restart, strategy ownership mismatch, invalid checkpoint data, and persistence failure state.

## Verification
Run from the `backend` directory:

```bash
PYTHONPATH=. pytest -q
```

Expected result for this package: **59 passed**.

## Required server configuration
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` (server-side only; never expose with a `NEXT_PUBLIC_` prefix)
- Existing Supabase JWT verification configuration required by `app/supa_auth.py`.

The Stage 7/9 SQL migration must have been reviewed and applied to the intended Supabase project before using these persistence routes. Do not run it against production without a backup and a deliberate deployment window.

## Safety limitations
- All broker purchases remain locked; live trading remains disabled.
- The current persistence connection is checkpoint-level. The Deriv buy/settlement workflow is not yet wired to atomically register purchases and apply settlement RPCs.
- The strategy engine still runs in one backend process per worker. Multiple Render workers can hold independent in-memory copies; do not scale horizontally until a database-backed coordination/locking design is added.
- This stage does not persist digit-frequency rolling buffers or unfinished trigger sequences. After restart, fresh market statistics and a new trigger sequence are required.
- A checkpoint write failure pauses this user's analysis request; it does not silently continue as if persistence succeeded.
- A checkpoint is not proof that an open contract is still open at Deriv. A future recovery stage must reconcile each recorded contract with Deriv before any trading workflow can resume.

## Deployment status
Development package only. No GitHub, Vercel, Render, or Supabase project has been modified by this work.
