# Stage 16 — Simulated Demo workflow verification

## Scope
This stage adds a route-level integration test for the existing read-only Demo workflow. It exercises, in sequence:

1. authenticated Demo preflight using a simulated Demo balance and proposal;
2. idempotent purchase-intent creation using a simulated persistence adapter;
3. read-only reconciliation of a Deriv-confirmed open contract and simulated atomic contract registration;
4. read-only reconciliation of a Deriv-confirmed sold contract and simulated idempotent settlement persistence; and
5. confirmation that the `/account/demo/buy` endpoint remains HTTP 423 (locked).

The test is `tests/test_stage16_demo_workflow.py`. It uses FastAPI's TestClient and monkeypatched adapters. It does not contact Deriv or Supabase and does not place a trade.

## Test result
Run from this directory:

```bash
PYTHONPATH=. pytest -q
```

Result in this development environment: **81 passed**.

## Safety / limitations
- No Deriv `buy` operation has been implemented or enabled.
- All workflow services in the new integration test are simulated. This is API orchestration coverage, not live end-to-end verification.
- The Stage 7/13/15 SQL migrations have not been applied to the user's Supabase project or verified against its live schema.
- A real Demo workflow still requires controlled live verification of OAuth permissions, OTP/WebSocket behavior, proposal response fields, contract monitoring, database RPC behavior, and restart recovery.
- Do not deploy this package or enable purchases based solely on this test result.
