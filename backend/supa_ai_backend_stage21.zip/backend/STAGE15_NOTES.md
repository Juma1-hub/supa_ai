# Stage 15 — Durable purchase-intent reconciliation foundation

## Included
- Added `purchase_reconciliation.py` to compare a read-only Deriv `proposal_open_contract` response with the stored intent's market, digit contract type, currency and bound ask price.
- Expanded the read-only contract monitor result to return the fields needed for matching.
- Added `get_demo_purchase_intent()` with both `user_id` and `intent_id` filters.
- Added a service-role RPC adapter for `confirm_demo_purchase_and_register_contract()`.
- Added migration `202611010003_stage15_execution_journal.sql`. The RPC atomically transitions a user's intent to `PURCHASE_CONFIRMED`, records the Deriv contract in `open_contracts`, and updates the user's runtime checkpoint. Repeated registration returns false; mismatched ownership/state is rejected.
- Added authenticated, read-only endpoint `POST /account/demo/purchase-intents/reconcile`. It does not call Deriv `buy`; it requires the authenticated user's intent, the same linked Demo account, a Deriv-confirmed open/sold contract, matching contract attributes, and an available matching runtime before invoking the atomic database RPC.

## Safety boundary
- No Deriv purchase operation has been added or enabled.
- `/account/demo/buy` remains locked (HTTP 423).
- The endpoint accepts a contract ID to reconcile an already-existing contract. Matching symbol/type/currency/price is a consistency check, not cryptographic proof that the contract originated from the proposal ID. It must not be treated as proof of proposal-to-purchase causality or as permission to automate buying.
- The SQL migration has not been run against the user's Supabase project. Live Deriv and Supabase integration has not been tested; automated tests use local/simulated data.
- Do not deploy until the migration is reviewed against the actual Stage 7/9/13 schema and end-to-end tests are completed.

## Tests
Run from this directory with `PYTHONPATH=. pytest -q`.
