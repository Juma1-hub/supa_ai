# Supa AI Backend — Stage 13

## Scope: idempotent Demo purchase-intent journal (purchase remains disabled)

Stage 13 adds a durable intent record before any future external purchase attempt. It deliberately does **not** send Deriv's `buy` request and does not enable `/account/demo/buy`.

### Added

- `POST /account/demo/purchase-intents` requires the existing Supabase user authentication and a Deriv OAuth bearer token.
- Rechecks Demo account type/currency, approved per-user runtime, persistence readiness, current stake, session risk limits, open-contract limit and available balance.
- Obtains a fresh Deriv proposal and binds the intent to the returned proposal ID and ask price.
- Persists a user-owned intent through the new `create_demo_purchase_intent` Supabase RPC.
- Requires a client-generated UUID idempotency key. Reusing the same key with the same request returns the same durable intent; reusing it with different parameters is rejected by the database function.
- SQL verifies that the Deriv Demo account is linked to the authenticated Supa AI user, and that the approved strategy and durable runtime checkpoint belong to that user.
- Intent status is `PREPARED_PURCHASE_DISABLED`; API response explicitly reports `purchase_enabled=false` and `deriv_buy_sent=false`.

### New migration

`supabase/migrations/202611010002_stage13_demo_purchase_intents.sql`

It creates `demo_purchase_intents`, own-row SELECT RLS, and a service-role-only RPC. It depends on the Stage 7/9 migration already present in this package. Do not run it in production until the entire migration chain is reviewed and tested in a separate Supabase project.

### Tests

Run:

```bash
PYTHONPATH=. pytest -q
```

Result in this development environment: **69 passed**.

Tests use mocked Deriv and Supabase calls. They do not prove live Deriv/Supabase connectivity or validate the SQL against the user's project.

### Explicitly not implemented

- No Deriv `buy` request is sent.
- No contract is created or registered by this endpoint.
- No claim of exactly-once external purchase is made. A database idempotency key alone cannot guarantee exactly-once behaviour across an external broker call. If a future buy request times out after Deriv may have accepted it, the workflow must enter an `UNKNOWN` state and reconcile with Deriv before any retry.
- Final purchase execution, immediate post-buy contract registration, broker-side crash recovery, and multi-worker locking remain future work.

Do not deploy this package over the current service yet.
