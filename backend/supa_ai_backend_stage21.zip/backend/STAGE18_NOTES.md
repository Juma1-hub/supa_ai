# Supa AI Backend — Stage 18: Verified Demo Account Linking

## Implemented
- `/account/demo/verify` now performs the existing read-only Deriv Demo identity/balance check and, only after Deriv confirms the requested account ID and Demo type, persists the account metadata for the authenticated Supa AI user.
- New `GET /account/demo/links` returns only the authenticated user's linked Demo account metadata.
- Added `verified_at` and a global unique constraint on `deriv_account_id`, preventing one Deriv account from being claimed by multiple Supa AI users.
- Added service-role-only RPCs `link_verified_demo_account` and `list_my_demo_accounts`. The backend supplies the Supabase-authenticated user ID; browser clients cannot call these RPCs.
- Only account ID, account type, currency and verification timestamp are persisted. Deriv OAuth tokens are request-only and are not stored or returned.
- Account linking is metadata/identity association only. It does not authorize a purchase.

## Safety boundaries
- Demo-only. The existing account table intentionally constrains `account_type` to `demo`.
- Real-account backend verification/linking is not implemented in this stage.
- No Deriv buy request was added. `/account/demo/buy` remains locked (HTTP 423), and `trading_enabled` remains false.
- No frontend, GitHub, Vercel, Render or Supabase production changes were made.
- The SQL migration has NOT been applied. Review and apply it in Supabase only when explicitly ready. Its global unique index will fail if historical data already has the same Deriv account linked to different users; inspect and resolve such rows before applying.

## Validation
Run from this backend directory:

```bash
PYTHONPATH=. pytest -q
```

Result in this build: **89 passed**. These tests mock Supabase/Deriv boundaries; they do not prove the migration against a live Supabase project or make live Deriv requests.

## Migration
`supabase/migrations/202611010004_stage18_verified_demo_account_links.sql`
