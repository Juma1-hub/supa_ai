# Stage 14 — execution transaction safety foundation

This stage adds a conservative execution-state model and fresh-check validation. It does **not** implement or enable a Deriv `buy` request.

## Safety properties
- Fresh checks require a Demo account, matching account and currency, approved strategy, available durable storage, clear risk limits, and a fresh proposal whose ask price does not exceed the fresh balance.
- Intent progression is explicit: `PREPARED_PURCHASE_DISABLED` -> `READY_FOR_EXPLICIT_DEMO_AUTHORIZATION` -> `PURCHASE_UNKNOWN` or `PURCHASE_CONFIRMED`.
- Once a request may have been sent and its outcome is unknown, automatic retry is forbidden. Reconciliation must resolve the outcome first.
- A purchase is considered confirmed only with a numeric Deriv contract ID.
- Failed checks abort the intent; they do not send an order.

## Deliberately not included
- No Deriv `buy` call.
- No endpoint transitions an intent into a state that authorizes an actual purchase.
- No Demo or live trade was placed.
- This state machine is a tested foundation; database transaction wiring and real Demo end-to-end verification remain required before any purchase can be enabled.

## Tests
Run `pytest -q` from the `backend` directory.
