# Stage 17 — Read-only Demo identity and proposal response verification

## Scope
- Added `POST /account/demo/verify`, requiring both a verified Supa AI Supabase bearer identity and a Deriv OAuth bearer token.
- The route requests the authenticated Demo balance and verifies that the returned account ID matches the requested account ID and that Deriv resolved it as Demo.
- The response explicitly states `account_link_persisted: false` and `trading_enabled: false`. This is a per-request identity check, not a permanent account-linking feature.
- Hardened Demo proposal response validation: payout, ask price and spot must be present, parse as finite decimal values, and satisfy basic positivity constraints before being returned.
- Added tests for missing Deriv credentials, successful Demo verification, account-ID mismatch, and malformed/non-finite proposal amounts.

## Test
Run from `backend/`:

```bash
PYTHONPATH=. pytest -q
```

Result in this development environment: **85 passed**.

## Not verified / not included
- No live Deriv or Supabase request was made by these tests; service calls are mocked.
- The user's frontend account selector and balance refresh were manually confirmed by the user, but that does not independently verify backend identity binding.
- This stage does not persistently link a Deriv account to a Supa AI user. It verifies the supplied Demo account for the current authenticated request only.
- No Real-account backend verification route is added. Real-account trading remains unsupported/disabled.
- Proposal requests are not confirmed against a live Deriv account in this development session.
- No Deriv `buy` request exists or is enabled. The purchase endpoint remains locked.
- Do not deploy until live read-only verification and Supabase schema checks are completed.
