# Supa AI — Stage 5 (Demo proposal preview; purchase locked)

## Added

- `POST /account/demo/proposal`: requests a price proposal using the selected Demo account's authenticated OTP WebSocket session.
- Supports ODD and EVEN digit contracts (`DIGITODD`, `DIGITEVEN`) on the ten configured volatility symbols.
- Uses 1 tick for standard volatility indices and 2 ticks for 1-second volatility indices.
- Returns quote details only. Proposal IDs are deliberately not returned or retained by this endpoint.
- `POST /account/demo/buy`: explicitly returns HTTP 423 Locked. No code path sends a `buy` message.

## Safety boundaries

- This is proposal preview only, not automated Demo execution.
- No purchase, sell, or settlement subscription is implemented in this stage.
- Live and Demo purchasing remain disabled.
- The proposal route requires a Deriv OAuth Bearer token and Demo account OTP URL; the URL is checked against the official Demo WebSocket host/path.
- The token is used only for the OTP request and is not persisted or logged.
- The endpoint is not ready for public deployment until Supa AI user authentication, account ownership checks, rate limiting, and secure session/token handling are added.
- A mocked test suite does not replace a real Deriv Demo account integration test.

## API examples

`POST /account/demo/proposal`

JSON body:

```json
{
  "account_id": "VRTC...",
  "symbol": "R_100",
  "contract": "ODD",
  "stake": "1.00",
  "currency": "USD"
}
```

Header: `Authorization: Bearer <Deriv OAuth access token>`

`POST /account/demo/buy` is intentionally locked and returns HTTP 423.

## Tests

Run from this directory:

`PYTHONPATH=. pytest -q`

Stage 5 suite: 38 passing tests.
