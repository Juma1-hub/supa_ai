# Supa AI Backend — Stage 11

## Scope
Stage 11 adds a read-only restart reconciliation workflow for persisted Demo open contracts.

### New endpoint
`POST /account/demo/contracts/reconcile`

Required headers:
- `Authorization: Bearer <Supabase access token>`
- `X-Deriv-Access-Token: Bearer <Deriv Demo OAuth access token>`

JSON body:
```json
{"account_id":"VRTC...", "limit":20, "timeout_seconds":10}
```

The backend:
1. Verifies the Supa AI user through the existing Supabase Auth dependency.
2. Loads only that user's persisted OPEN contracts for the requested linked Demo account using a service-role-only Supabase RPC.
3. Checks each contract with Deriv's authenticated Demo `proposal_open_contract` stream.
4. Does not modify anything for contracts Deriv still reports open or for which no update arrives.
5. For contracts Deriv confirms as sold, calls the existing atomic `apply_confirmed_settlement` RPC. The contract ID is the idempotency key; a repeated settlement cannot update P/L or Martingale twice.

The existing single-contract `/account/demo/contract/monitor` endpoint is now read-only and no longer mutates the old process-global engine.

## Migration
The Stage 11 SQL function is appended to the existing migration:
`supabase/migrations/202611010001_stage7_security_persistence.sql`

It creates `list_reconcilable_open_contracts`, which is executable only by `service_role`. It returns records scoped to the supplied user ID and account ID, and joins only linked Demo accounts and that user's active runtime checkpoint/strategy.

## Safety limitations
- This does not enable buying. `/account/demo/buy` remains HTTP 423 locked.
- This endpoint reconciles persisted contract records only; it cannot recover contracts that were never durably registered after a confirmed purchase.
- It requires a valid Deriv Demo OAuth token at reconciliation time; tokens are not stored.
- The endpoint does not resume strategy entries after reconciliation. A separate explicit recovery/approval flow is required.
- The service-role key must remain server-side. Do not place it in Vercel `NEXT_PUBLIC_*` variables or browser code.
- The migration has not been run against the user's Supabase project. Validate it in a non-production project first.
- Automated tests mock Deriv and Supabase; they do not constitute live Deriv or Supabase integration verification.

## Test result
Run from this directory with `PYTHONPATH=.`:
`pytest -q`

Result at package creation: 62 passed.
