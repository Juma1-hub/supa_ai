# Supa AI Backend — Stage 9: durable state and settlement transaction foundation

## Included

- `runtime_checkpoints` table for restart-safe strategy ID, Martingale step, session P/L and tracked open contract IDs.
- `register_open_contract` Postgres RPC to atomically register an already Deriv-confirmed open contract and checkpoint.
- `apply_confirmed_settlement` Postgres RPC to lock the user's checkpoint, verify the contract belongs to that user and is OPEN, insert a unique settlement record, update P/L and Martingale progression, and update the next stake in one database transaction.
- Backend service-role adapter functions for checkpoint save/load and RPC calls. Deriv OAuth tokens are not accepted in checkpoint payloads.
- Strict payload validation tests.

## Important integration boundary

This stage provides database schema and transaction primitives. It does NOT yet wire the current demo monitor/purchase routes into these operations, because the purchase endpoint is deliberately locked and there is no verified Deriv buy response in the current code. It also does not restore a complete in-memory market-trigger state after restart. A confirmed Deriv buy must be recorded only after its real contract ID is received; a settlement must be applied only after Deriv confirms the sold contract and currency/profit.

## Migration

The SQL migration extends the existing Stage 7 migration. Apply it only after the Stage 7 tables exist. Review it in Supabase SQL Editor first. It grants the two write RPCs only to `service_role`; never expose `SUPABASE_SERVICE_ROLE_KEY` in the frontend.

## Safety

- Demo purchase endpoint remains HTTP 423 locked.
- Live trading remains disabled.
- No broker orders are sent by this stage.
- No deployment is approved by this package alone.

## Verification

Automated tests validate payload contracts and existing engine/user isolation behaviour. They do not execute the SQL against a live Supabase project. The SQL migration must be tested in a non-production Supabase project before deployment.
