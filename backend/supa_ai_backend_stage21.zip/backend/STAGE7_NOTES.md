# Supa AI Backend — Stage 7 security and persistence foundation

## Included
- Supabase Auth identity verification through `GET /auth/v1/user`.
- Sensitive Demo-account and strategy endpoints require a Supa AI Supabase bearer token.
- Deriv OAuth is carried separately in `X-Deriv-Access-Token`; the two credentials are never conflated.
- Strategy drafts are persisted with an owner UUID through the backend-only Supabase service-role key.
- Draft lookup and approval are scoped by both draft ID and authenticated Supabase user ID.
- SQL migration creates user-owned tables and Row Level Security policies. No Deriv access tokens are stored.
- Shared global strategy state and market-data activation are deliberately paused so one user's strategy state cannot leak into another user's session while per-user runtime isolation is unfinished.
- Demo purchase endpoint remains locked; no buy request is sent.

## Required backend environment variables
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` — used only to verify Supabase access tokens.
- `SUPABASE_SERVICE_ROLE_KEY` — backend only; never expose as `NEXT_PUBLIC_*` or put in frontend code.
- Existing `DERIV_APP_ID` remains required for Deriv account operations.

## Supabase setup
Run `supabase/migrations/202611010001_stage7_security_persistence.sql` in the Supabase SQL editor. The migration enables RLS and adds owner-scoped policies. Keep the service-role key only in the Render backend environment.

## API credential headers
For protected Demo account routes:
- `Authorization: Bearer <Supabase access token>`
- `X-Deriv-Access-Token: Bearer <Deriv OAuth access token>`

The frontend must obtain the Supabase session token and send both headers separately. Do not store either token in strategy rows or logs.

## Important incomplete work — not production-ready
- This stage is a security/persistence foundation, not complete multi-user trading isolation.
- Per-user strategy engine instances, durable progression restoration, atomic/idempotent settlement transactions, and per-user market feed routing remain to be implemented.
- To avoid cross-user state exposure, shared engine snapshot/market-stat mutation and market-data start are locked.
- Demo buy remains locked (HTTP 423). No trade execution is enabled.
- Frontend OAuth/session integration and live Supabase project migration have not been exercised in this environment.

## Tests
Run from `backend/` with `PYTHONPATH=.`: `pytest -q`.
