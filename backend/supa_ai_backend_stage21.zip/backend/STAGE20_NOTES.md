# Supa AI Backend — Stage 20

## Scope
- Real account verification now persists verified account metadata through the same `deriv_account_links` table used for Demo accounts.
- Added a unified `GET /account/links` endpoint returning both Demo and Real account metadata for the authenticated Supa AI user.
- Added service-role-only RPCs `link_verified_deriv_account` and `list_my_deriv_accounts`.
- Expanded the database account-type constraint from Demo-only to `demo` or `real`.
- The existing global unique index on `deriv_account_id` remains the cross-user ownership boundary.
- Deriv OAuth tokens are used per request only; they are not written to Supabase or returned by these endpoints.

## Migration
Apply `supabase/migrations/202611010005_stage20_unified_deriv_account_links.sql` only after reviewing the schema and confirming Stage 18 migration was applied successfully. The migration assumes the Stage 18 global unique index exists. It does not inspect or mutate production data beyond changing the account-type constraint and creating/replacing RPC functions.

## Safety
- Account linking is metadata-only.
- Demo purchase endpoint remains locked.
- Real trading is not implemented.
- No Deriv Real OTP or WebSocket connection is opened.
- Existing Demo purchase/reconciliation functions remain Demo-scoped.

## Verification
Run from this directory:

```bash
PYTHONPATH=. pytest -q
```

Result during Stage 20 packaging: **96 passed**. Tests use mocked Deriv/Supabase calls. No live Deriv request, Supabase migration, or production deployment was performed.
