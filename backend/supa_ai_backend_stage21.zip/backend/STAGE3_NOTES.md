# Supa AI backend — Stage 3 strategy integration

## Added
- `POST /strategy/draft`: accepts an explicit structured strategy, validates supported fields and returns the exact interpreted rules with `AWAITING_REVIEW` status.
- `POST /strategy/approve/{draft_id}`: applies a reviewed draft to the in-memory analysis engine only.
- Strategy approval resets market qualification and partial trigger sequences so all markets must supply fresh statistics under the new rules.
- Confirmed Martingale progression and session P/L are preserved when a new strategy is approved.
- Execution remains disabled; the response explicitly reports `execution_enabled: false`.

## Deliberate limitations
- Only ODD contracts are currently supported by the strategy engine. EVEN requests are rejected explicitly rather than silently translated.
- The draft registry and engine state are in process memory and are lost on restart. This is a development-stage implementation, not durable production storage.
- This API accepts structured fields, not unrestricted natural-language instructions. A natural-language parser and trader review UI remain separate work.
- Authentication/authorization is not added to these development routes. Do not expose strategy approval endpoints publicly before securing them.
- No proposal, buy, sell, or account-scoped Deriv calls are made. Live trading remains locked.

## Tests
Run `python -m pytest -q` from this backend directory. Stage 3 suite: 30 passed.
