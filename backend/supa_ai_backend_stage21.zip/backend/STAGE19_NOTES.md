# Supa AI Backend — Stage 19: Read-only Real Account Verification

## Implemented
- Added `fetch_real_account_metadata`, which calls Deriv's documented authenticated `GET /trading/v1/options/accounts` endpoint.
- The helper finds the requested account in the account list returned for the supplied OAuth bearer token and requires `account_type == real`.
- Added `POST /account/real/verify`, protected by Supabase authentication and a per-request Deriv OAuth bearer token.
- Response includes verified account ID, Real type, currency and status. It explicitly reports `account_link_persisted: false` and `trading_enabled: false`.
- The Deriv token is used only in the outbound request and is not persisted, returned, or logged.

## Deliberate limits
- This stage verifies identity only. It does not persist Real account links because the Stage 18 database schema and RPCs are Demo-only. Extending the schema safely requires a separate migration and review of existing account-link data.
- No Real OTP is requested and no Real WebSocket is opened.
- No proposal, buy, sell, or other Real-money operation was added.
- Existing Demo linking remains unchanged. Purchases remain locked and `trading_enabled` remains false.
- No frontend, GitHub, Vercel, Render, or production Supabase changes were made.

## Deriv documentation basis
- `GET /trading/v1/options/accounts` returns Options accounts associated with the authenticated credentials, including Demo and Real accounts. OAuth scope documented: `trade`.
- Source: https://developers.deriv.com/docs/options/get-accounts/

## Validation
Run from this backend directory:

```bash
PYTHONPATH=. pytest -q
```

Result in this build: **93 passed**. Deriv and Supabase boundaries are mocked in tests; no live account was queried and no production service was changed.
