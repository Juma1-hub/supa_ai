# Supa AI — Stage 4 (Demo account read-only integration)

## Added

- `POST /account/demo/balance`
- Accepts a Deriv OAuth access token only in the HTTP `Authorization: Bearer ...` header.
- Accepts a Deriv account ID in JSON: `{"account_id":"VRTC..."}`.
- Calls the Deriv Options account OTP endpoint, verifies that the returned WebSocket URL is the official Deriv Demo endpoint, then requests one balance response.
- Returns the balance as a decimal string plus currency and account type.
- Does not persist the access token, OTP URL, or balance subscription.
- Does not expose proposal, buy, sell, or other execution actions. `trading_enabled` remains false.

## Required environment variable

Set `DERIV_APP_ID` on the backend to the Deriv application ID. Do not put OAuth access tokens or OTPs in environment variables, source files, frontend bundles, logs, or GitHub.

## Example request

`POST /account/demo/balance`

Header: `Authorization: Bearer <short-lived Deriv OAuth access token>`

JSON body: `{"account_id":"VRTC..."}`

The access token is a secret. This example is documentation only; do not paste a real token into chat or commit it.

## Important limitations / deployment blockers

1. This endpoint is a development integration, not a complete production account-authentication system. Before public deployment it must be protected by Supa AI user authentication, ownership checks, rate limiting, and secure server-side session/token handling.
2. The current frontend's exact OAuth callback/token format has not been re-verified against this backend endpoint. The frontend must securely pass the correct Deriv OAuth access token and selected Demo account ID.
3. The endpoint reads one balance snapshot; it does not keep a live balance subscription.
4. It intentionally rejects a WebSocket URL resolving to a Real account.
5. A real Deriv OAuth session is required for an end-to-end test. Automated tests use mocked Deriv responses and do not prove live account connectivity.
6. No trade execution is implemented or enabled.

## Tests

Run from this directory:

`PYTHONPATH=. pytest -q`

The Stage 4 development suite contains 33 passing tests.
