# Supa AI Stage 8 — per-user strategy runtime isolation

## Included
- Added `app/user_runtime.py`, a registry that creates a separate `StrategyEngine` per authenticated Supabase user.
- A runtime can only be created from an approved strategy draft with the exact supported rule fields. Missing or unexpected fields are rejected.
- Strategy approval now creates/replaces only that user's analysis runtime after the owned draft has been loaded and approved in Supabase.
- `/strategy/status` and `/strategy/snapshot` now return only the authenticated user's runtime state.
- `/strategy/validate-stats` routes statistics only into that authenticated user's runtime. It cannot write to the old shared engine.
- The old global market collector remains paused; no market feed is routed across users.
- Purchase endpoint remains locked; trading is disabled.

## Verification
- Automated backend test suite: 50 passed.
- Includes tests proving two users receive distinct engine instances and Martingale state is not shared.
- Includes tests rejecting unapproved or malformed strategy drafts.

## Critical limitations
- Runtime state is currently process-local. A Render restart loses active runtime state, market trigger state, Martingale step and open-contract tracking. Do not use this runtime for live or Demo execution.
- Strategy approval is stored in Supabase, but the per-user engine state is not yet restored from durable storage.
- No authenticated market-data worker routes ticks to individual user engines yet.
- The `/strategy/validate-stats` route accepts a source label supplied by the caller; this does not authenticate the origin of the data.
- No Deriv purchases are enabled. `/account/demo/buy` remains HTTP 423 locked.

## Deployment
Do not replace the deployed backend with this package yet. It is a development milestone only. Stage 9 must implement durable per-user runtime state, atomic settlement/progression persistence, and safe recovery after restarts before Demo execution is considered.
