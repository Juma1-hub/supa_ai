# Supa AI backend — Stage 2 development notes

This package adds a read-only automatic market selector.

## Behaviour
- Keeps the currently selected market while its latest statistics remain fresh and qualifying.
- If it stops qualifying or its statistics become stale, selects another fresh qualifying market.
- Uses a deterministic alphabetical tie-break when several alternatives qualify.
- Only the selected market's ticks may advance its digit-trigger sequence.
- Partial trigger sequences are reset when switching markets; ticks from different symbols are never combined.
- Martingale progression is engine-wide and is not reset by a market switch.
- No proposal, buy, sell, or account-scoped request is added. Live execution remains locked.

## Limitations
- Selection occurs when complete rolling statistics are updated or when a tick is processed; this is not a separate always-running scheduler.
- The engine and collector remain process-local and are not persistent across Render restarts.
- The selector is a technical implementation of market eligibility, not a guarantee that any market is profitable.
- Public-feed source labels are not independently authenticated by the API's manual stats endpoint.
- Do not deploy until the live Deriv feed schema and reconnect behaviour have been verified in a controlled environment.

## Tests
Run from this directory:
`python -m pytest -q`

The package's automated test suite passed 25 tests in the development environment.
