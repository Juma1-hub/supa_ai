# Supa AI Backend — Stage 21 compatibility

No backend runtime or database migration changes are required for the Stage 21 frontend authentication integration. Stage 20 already exposes the required authenticated endpoints:

- `POST /account/demo/verify`
- `POST /account/real/verify`
- `GET /account/links`

Each endpoint verifies the Supabase bearer token through Supabase Auth. The verify endpoints also validate the selected Deriv account using the request-scoped Deriv OAuth token before persisting account metadata. The list endpoint is scoped to the authenticated Supabase user.

The frontend server routes proxy requests to these endpoints and keep the Deriv token in the existing HTTP-only cookie. The backend must be deployed with `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and the existing Supabase service-role configuration required by `supa_store.py`.

Trading remains disabled. Stage 20 migration `202611010005_stage20_unified_deriv_account_links.sql` must already be applied for unified Demo/Real account linking.

Verification: `PYTHONPATH=. pytest -q` — 97 passed during Stage 21 compatibility review. Tests use mocked services; no live Supabase or Deriv integration test was performed.
